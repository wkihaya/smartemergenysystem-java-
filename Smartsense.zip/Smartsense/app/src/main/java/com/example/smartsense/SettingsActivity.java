package com.example.smartsense;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Switch;

import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

    private Switch flashSwitch;
    private Switch vibrationSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Initialize switches
        flashSwitch = findViewById(R.id.switch_flash);
        vibrationSwitch = findViewById(R.id.switch_vibration);

        // Load saved preferences
        SharedPreferences preferences = getSharedPreferences("AlertPrefs", MODE_PRIVATE);
        boolean useFlash = preferences.getBoolean("useFlash", true);
        boolean useVibration = preferences.getBoolean("useVibration", true);

        flashSwitch.setChecked(useFlash);
        vibrationSwitch.setChecked(useVibration);

        // Save new settings when toggled
        flashSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            SharedPreferences.Editor editor = preferences.edit();
            editor.putBoolean("useFlash", isChecked);
            editor.apply();
        });

        vibrationSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            SharedPreferences.Editor editor = preferences.edit();
            editor.putBoolean("useVibration", isChecked);
            editor.apply();
        });
    }
}

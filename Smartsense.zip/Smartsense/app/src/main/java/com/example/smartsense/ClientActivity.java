package com.example.smartsense;

import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smartsense.adapter.AlertAdapter;
import com.example.smartsense.model.AlertModel;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ClientActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private AlertAdapter adapter;
    private List<AlertModel> alertList;
    private DatabaseReference alertsRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client);

        recyclerView = findViewById(R.id.recyclerViewAlerts);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        alertList = new ArrayList<>();
        alertsRef = FirebaseDatabase.getInstance().getReference("alerts");

        // isAdmin = false for client view
        adapter = new AlertAdapter(alertList, alertsRef, false);
        recyclerView.setAdapter(adapter);

        loadAlerts();
    }

    private void loadAlerts() {
        alertsRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                alertList.clear();
                for (DataSnapshot snap : snapshot.getChildren()) {
                    AlertModel model = snap.getValue(AlertModel.class);
                    if (model != null) {
                        alertList.add(model);
                    }
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ClientActivity.this, "Failed to load alerts", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

package com.example.smartsense;

import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smartsense.adapter.AlertAdapter;
import com.example.smartsense.model.AlertModel;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ReportsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private AlertAdapter adapter;
    private ArrayList<AlertModel> alertList;
    private DatabaseReference alertsRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reports);

        recyclerView = findViewById(R.id.recyclerReports);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        alertList = new ArrayList<>();
        alertsRef = FirebaseDatabase.getInstance().getReference("alerts");

        adapter = new AlertAdapter(alertList, alertsRef, true); // true = admin mode
        recyclerView.setAdapter(adapter);

        // Set adapter listener for edit/delete
        adapter.setOnAlertActionListener(new AlertAdapter.OnAlertActionListener() {
            @Override
            public void onEdit(AlertModel alert) {
                editAlert(alert);
            }

            @Override
            public void onDelete(AlertModel alert) {
                alertsRef.child(alert.getId()).removeValue()
                        .addOnSuccessListener(unused ->
                                Toast.makeText(ReportsActivity.this, "Alert Deleted", Toast.LENGTH_SHORT).show())
                        .addOnFailureListener(e ->
                                Toast.makeText(ReportsActivity.this, "Delete Failed", Toast.LENGTH_SHORT).show());
            }
        });

        loadAlerts();
    }

    private void loadAlerts() {
        alertsRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                alertList.clear();
                for (DataSnapshot data : snapshot.getChildren()) {
                    AlertModel alert = data.getValue(AlertModel.class);
                    if (alert != null) {
                        alert.setId(data.getKey()); // store Firebase ID
                        alertList.add(alert);
                    }
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ReportsActivity.this, "Failed to load alerts", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void editAlert(AlertModel alert) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Alert");

        EditText inputType = new EditText(this);
        inputType.setInputType(InputType.TYPE_CLASS_TEXT);
        inputType.setHint("Type");
        inputType.setText(alert.getType());

        EditText inputMessage = new EditText(this);
        inputMessage.setInputType(InputType.TYPE_CLASS_TEXT);
        inputMessage.setHint("Message");
        inputMessage.setText(alert.getMessage());

        android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setOrientation(android.widget.LinearLayout.VERTICAL);
        layout.addView(inputType);
        layout.addView(inputMessage);
        builder.setView(layout);

        builder.setPositiveButton("Update", (dialog, which) -> {
            alert.setType(inputType.getText().toString().trim());
            alert.setMessage(inputMessage.getText().toString().trim());
            alertsRef.child(alert.getId()).setValue(alert)
                    .addOnSuccessListener(unused ->
                            Toast.makeText(this, "Alert Updated", Toast.LENGTH_SHORT).show())
                    .addOnFailureListener(e ->
                            Toast.makeText(this, "Update Failed", Toast.LENGTH_SHORT).show());
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.show();
    }
}

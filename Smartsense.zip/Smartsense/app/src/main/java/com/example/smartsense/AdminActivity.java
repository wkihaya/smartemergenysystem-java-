package com.example.smartsense;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smartsense.adapter.AlertAdapter;
import com.example.smartsense.model.AlertModel;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class AdminActivity extends AppCompatActivity {

    private EditText alertTypeInput, alertMessageInput;
    private Button addAlertBtn;
    private RecyclerView alertsRecyclerView;

    private List<AlertModel> alertList;
    private AlertAdapter alertAdapter;
    private DatabaseReference alertsRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        // Firebase reference
        alertsRef = FirebaseDatabase.getInstance().getReference("alerts");

        // UI components
        alertTypeInput = findViewById(R.id.alertTypeInput);
        alertMessageInput = findViewById(R.id.alertMessageInput);
        addAlertBtn = findViewById(R.id.addAlertBtn);
        alertsRecyclerView = findViewById(R.id.alertsRecyclerView);

        alertsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        alertList = new ArrayList<>();
        alertAdapter = new AlertAdapter(alertList, alertsRef, true); // isAdmin = true
        alertsRecyclerView.setAdapter(alertAdapter);

        // Load alerts from Firebase
        loadAlerts();

        // Add new alert
        addAlertBtn.setOnClickListener(v -> addAlert());
    }

    private void loadAlerts() {
        alertsRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                alertList.clear();
                for (DataSnapshot snap : snapshot.getChildren()) {
                    AlertModel model = snap.getValue(AlertModel.class);
                    if (model != null) {
                        alertList.add(model);
                    }
                }
                alertAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(AdminActivity.this, "Failed to load alerts", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void addAlert() {
        String type = alertTypeInput.getText().toString().trim();
        String message = alertMessageInput.getText().toString().trim();

        if (TextUtils.isEmpty(type) || TextUtils.isEmpty(message)) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        String id = UUID.randomUUID().toString();
        long timestamp = System.currentTimeMillis();

        AlertModel alert = new AlertModel(id, type, message, timestamp);

        alertsRef.child(id).setValue(alert)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Alert added", Toast.LENGTH_SHORT).show();
                    alertTypeInput.setText("");
                    alertMessageInput.setText("");
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                );
    }
}

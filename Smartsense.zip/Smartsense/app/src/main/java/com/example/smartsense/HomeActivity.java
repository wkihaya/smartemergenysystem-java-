package com.example.smartsense;

import android.content.Context;
import android.content.Intent;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class HomeActivity extends AppCompatActivity {

    private Button btnAlert, btnSettings, btnReport, btnLogout;
    private boolean isAdmin = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        btnAlert = findViewById(R.id.btnAlert);
        btnSettings = findViewById(R.id.btnSettings);
        btnReport = findViewById(R.id.btnReport);
        btnLogout = findViewById(R.id.btnLogout);

        // Get role from Intent
        String role = getIntent().getStringExtra("role");
        isAdmin = role != null && role.equalsIgnoreCase("admin");

        btnAlert.setOnClickListener(v -> {
            triggerFlashAndVibrate();
            Toast.makeText(HomeActivity.this, "Emergency Alert Triggered!", Toast.LENGTH_SHORT).show();
        });

        btnSettings.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, SettingsActivity.class);
            startActivity(intent);
        });

        btnReport.setOnClickListener(v -> {
            if (isAdmin) {
                startActivity(new Intent(HomeActivity.this, ReportsActivity.class));
            } else {
                Toast.makeText(this, "Access denied: Admins only", Toast.LENGTH_SHORT).show();
            }
        });

        btnLogout.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        });
    }

    private void triggerFlashAndVibrate() {
        // Vibrate
        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        if (vibrator != null && vibrator.hasVibrator()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                vibrator.vibrate(500);
            }
        }

        // Flash
        CameraManager camManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            String cameraId = camManager.getCameraIdList()[0]; // Usually back camera
            camManager.setTorchMode(cameraId, true);
            new Handler().postDelayed(() -> {
                try {
                    camManager.setTorchMode(cameraId, false);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }, 1000); // Flash for 1 second
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

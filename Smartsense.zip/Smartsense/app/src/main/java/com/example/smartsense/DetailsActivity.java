package com.example.smartsense;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smartsense.adapter.AlertAdapter;
import com.example.smartsense.model.AlertModel;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class DetailsActivity extends AppCompatActivity {

    private RecyclerView alertsRecyclerView;
    private AlertAdapter alertAdapter;
    private ArrayList<AlertModel> alertList;
    private DatabaseReference alertsRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detaillayout);

        alertsRecyclerView = findViewById(R.id.alertsRecyclerView);
        alertsRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        alertList = new ArrayList<>();
        alertsRef = FirebaseDatabase.getInstance().getReference("alerts");

        // false because this is for viewing only, not admin
        alertAdapter = new AlertAdapter(alertList, alertsRef, false);
        alertsRecyclerView.setAdapter(alertAdapter);

        loadAlerts();
    }

    private void loadAlerts() {
        alertsRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                alertList.clear();
                for (DataSnapshot snap : snapshot.getChildren()) {
                    AlertModel model = snap.getValue(AlertModel.class);
                    if (model != null) {
                        model.setId(snap.getKey()); // set Firebase ID for delete/edit if needed
                        alertList.add(model);
                    }
                }
                alertAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Optional: log error
            }
        });
    }
}

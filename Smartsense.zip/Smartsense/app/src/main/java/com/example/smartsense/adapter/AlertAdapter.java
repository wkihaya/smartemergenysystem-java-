package com.example.smartsense.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smartsense.R;
import com.example.smartsense.model.AlertModel;
import com.google.firebase.database.DatabaseReference;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AlertAdapter extends RecyclerView.Adapter<AlertAdapter.AlertViewHolder> {

    private List<AlertModel> alertList;
    private DatabaseReference alertsRef;
    private boolean isAdmin;
    private Context context;

    // Listener interface for edit/delete actions
    public interface OnAlertActionListener {
        void onEdit(AlertModel alert);
        void onDelete(AlertModel alert);
    }

    private OnAlertActionListener listener;

    public void setOnAlertActionListener(OnAlertActionListener listener) {
        this.listener = listener;
    }

    public AlertAdapter(List<AlertModel> alertList, DatabaseReference alertsRef, boolean isAdmin) {
        this.alertList = alertList;
        this.alertsRef = alertsRef;
        this.isAdmin = isAdmin;
    }

    @NonNull
    @Override
    public AlertViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.alert_item, parent, false);
        return new AlertViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull AlertViewHolder holder, int position) {
        AlertModel alert = alertList.get(position);
        holder.typeText.setText(alert.getType());
        holder.messageText.setText(alert.getMessage());
        holder.timeText.setText(new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
                .format(new Date(alert.getTimestamp())));

        if (isAdmin) {
            holder.deleteBtn.setVisibility(View.VISIBLE);
            holder.editBtn.setVisibility(View.VISIBLE);

            holder.deleteBtn.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onDelete(alert);
                }
            });

            holder.editBtn.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onEdit(alert);
                }
            });

        } else {
            holder.deleteBtn.setVisibility(View.GONE);
            holder.editBtn.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return alertList.size();
    }

    static class AlertViewHolder extends RecyclerView.ViewHolder {
        TextView typeText, messageText, timeText;
        ImageButton deleteBtn, editBtn;

        AlertViewHolder(View itemView) {
            super(itemView);
            typeText = itemView.findViewById(R.id.alertType);
            messageText = itemView.findViewById(R.id.alertMessage);
            timeText = itemView.findViewById(R.id.alertTime);
            deleteBtn = itemView.findViewById(R.id.deleteBtn);
            editBtn = itemView.findViewById(R.id.editBtn);
        }
    }
}
